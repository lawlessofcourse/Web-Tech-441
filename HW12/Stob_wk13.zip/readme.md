## Week 13

this week was tricky but I felt like I had it down!! I think having the bones of the code from you (and a lot of the organs tbh) helped me with focusing on other things like how the organs work together to keep the human alive. I'm not really sure where I was going with that??????????? But I'm gonna keep it cause I like it and I think it works. Okay thank you for extending the due-date and all your help! I'm really happy right now because I got myself in a few dead ends and got myself out of all of them except for the one I posted on the issues!!! Thank you!
