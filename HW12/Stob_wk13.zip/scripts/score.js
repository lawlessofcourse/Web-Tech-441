function drawScore(){

fill(255, 255, 0);
textSize(30);
text("Score: " + score, 20, 30);
}
